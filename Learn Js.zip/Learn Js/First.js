
const burl = "https://v6.exchangerate-api.com/v6/bc36272978502faf88630550/latest/";
let result=document.querySelector(".price");
// Select dropdowns for base and target currencies
let dropdown1 = document.querySelectorAll(".majorpartdiv1 select");
let dropdown2 = document.querySelectorAll(".majorpartdiv2 select");

// Button to trigger exchange rate conversion
let exchangeratebutton = document.querySelector("#price1");
let fromcr = document.querySelector(".majorpartdiv1 select"); // Base currency
let tocr = document.querySelector(".majorpartdiv2 select"); // Target currency

// Populate the currency dropdowns
for (let select of dropdown1) {
    for (let code in countryList) {
        let newoption = document.createElement("option");
        newoption.innerText = code;
        newoption.value = code;
        if (select.name === "from" && code === "USD") {
            newoption.selected = "selected"; // Set default "from" to USD
        }
        select.append(newoption);
    }
    select.addEventListener("change", (evt) => {
        updateflag(evt.target);
    });
}

for (let select of dropdown2) {
    for (let code in countryList) {
        let newoption = document.createElement("option");
        newoption.innerText = code;
        newoption.value = code;
        if (select.name === "to" && code === "INR") {
            newoption.selected = "selected"; // Set default "to" to INR
        }
        select.append(newoption);
    }
    select.addEventListener("change", (evt) => {
        updateflag(evt.target);
    });
}

// Function to update country flag based on selected currency
const updateflag = (element) => {
    let code = element.value;
    let citycode = countryList[code]; // Ensure 'countryList' contains proper mappings
    let newsource = `https://flagsapi.com/${citycode}/flat/64.png`;
    let img = element.parentElement.querySelector("img");
    if (img) {
        img.src = newsource; // Update flag image source if <img> exists
    }
};

// Event listener for the button to fetch exchange rate
exchangeratebutton.addEventListener("click", async (evt) => {
    evt.preventDefault(); // Prevent default form submission

    let amount = document.querySelector("input");
    let amval = amount.value;
    if (amval === "" || amval < 1) {
        amval = 1; // Set default amount if input is empty or less than 1
        amount.value = "1";
    }

    // Construct the API URL with the selected currencies
    let URL = `${burl}${fromcr.value}`;
  let response=await fetch(URL);
  let data=await response.json();
  let exchangeerate=data.conversion_rates[tocr.value];
let actualamount=amval*exchangeerate;
console.log(result.innerText=`Conversion Rate is:${actualamount}`);
});
